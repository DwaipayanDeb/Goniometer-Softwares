﻿Imports System.Threading
'Imports System.Threading.Thread 
Imports System.IO.Ports
Imports System.Math

Public Class Form1
    Dim WithEvents ArduinoPort As New SerialPort
    Dim Laser As String = "L0"
    Dim LaserFxd As String = "L0"
    Dim DataCapturing As String = "OFF"
    Dim dataAutoguide As Boolean = False
    Dim pauseCapture As Boolean = False
    Dim TaskComplete As Boolean = False
    Dim Motorid As String = "N"
    Dim Motorstep As Integer = 0
    Dim Motordir As String = "R0"
    Dim ManualSend As String = "L0R0N0"
    Dim fixing As String = "NOTDONE"
    Dim finish As String = "DONE"
    Dim i As Integer = 0
    Dim j As Integer = 0
    Dim k As Integer = 0
    Dim D As Single = 0
    Dim C As Single = 0
    Dim time1 As Integer = 0
    Dim time2 As Integer = 0
    Dim CaptureNumber As Integer = 1
    Dim FileCheckStatus As Boolean = False
    Dim NewValue As Boolean = False
    Dim fixedangle As Single = 0
    Dim startangle As Single = 0
    Dim stopangle As Single = 0
    Dim stepsmall As Single = 0
    Dim steplarge As Single = 0
    Dim backscatt As Single = 0
    Dim starti As Single = 0
    Dim starte As Single = 0
    Dim stepie As Single = 0
    Dim offseti As Single = 0
    Dim offsete As Single = 0
    Dim xAngle() As Single

    Dim iAngle As New List(Of Single)()
    Dim eAngle As New List(Of Single)()
    Dim DetectorValue As New List(Of Single)()
    Dim ComparatorValue As New List(Of Single)()
    Dim BDR As New List(Of Single)()
    Dim RelFluxDens As Single = 1
    Dim iAngleAv As Single = 0
    Dim eAngleAv As Single = 0
    Dim DetectorValueAv As Single = 0
    Dim ComparatorValueAv As Single = 0
    Dim SerialNo As Integer = 0 ' Maximum limit is -2147483648 to 2147483647
    Dim serialdatapath As String = "c:\My App Files\Goniometer Controller\"
    Dim filepath As String

    'Dim btn1Thread As New Threading.Thread(New Threading.ThreadStart(AddressOf Me.Button1.PerformClick))
    'Dim btn1thrd As New Threading.Thread(AddressOf btn1text)
    Private Sub Form1_FormClosed(sender As Object, e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        My.Settings.PortIndex = ComboBox1.SelectedIndex
        My.Settings.Angles(0) = incidenceAngle.Value
        My.Settings.Angles(1) = NumericUpDown1.Value
        My.Settings.Angles(2) = NumericUpDown4.Value
        My.Settings.Angles(3) = NumericUpDown7.Value
        My.Settings.Angles(4) = NumericUpDown2.Value
        My.Settings.Angles(5) = NumericUpDown3.Value
        My.Settings.Angles(6) = NumericUpDown5.Value
        My.Settings.Angles(7) = NumericUpDown6.Value
        My.Settings.SampleSize = NumericUpDown8.Value
        My.Settings.ManStep = NumericUpDown9.Value
        My.Settings.Angles(8) = NumericUpDown10.Value
        My.Settings.FixedButton1 = RadioButton1.Checked
        My.Settings.FixedButton2 = RadioButton2.Checked
        My.Settings.FixedButton3 = RadioButton3.Checked
        My.Settings.FilePath = TextBox2.Text
        My.Settings.SampleDetails = RichTextBox1.Text
        My.Settings.RelFlux = TextBox1.Text
        My.Settings.OffsetAnglei = NumericUpDown11.Value
        My.Settings.OffsetAnglee = NumericUpDown12.Value
        My.Settings.CaptureNo = NumericUpDown13.Value
        'If ArduinoPort.IsOpen Then ArduinoPort.Close()
 
        If CheckBox3.Checked = True And TaskComplete = True Then
            Process.Start("shutdown", "-s")
            'MsgBox("closed")
        End If

    End Sub

    Private Sub Form1_FormClosing(sender As Object, e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        If ArduinoPort.IsOpen Then
            MsgBox("Please Disconnect serial port first.")
            e.Cancel = True

        End If
    End Sub
    Private Sub Form1_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Chart1.ChartAreas("ChartArea1").AxisX.Title = "Data Number"
        Chart1.ChartAreas("ChartArea1").AxisY.Title = "Normalized Flux"
        Chart1.ChartAreas("ChartArea1").AxisX.MajorGrid.LineColor = Color.Gainsboro
        Chart1.ChartAreas("ChartArea1").AxisY.MajorGrid.LineColor = Color.Gainsboro
        'Chart1.Series(0).ToolTip = "#VALX{}"
        'Chart1.Series(0).ToolTip = "#VALY{}"
        'MsgBox(My.Settings.Angles(4))
        ToolTip1.SetToolTip(Label6, "Step angle under Back Scattering angle (see below)")
        ToolTip1.SetToolTip(Label13, "Step angle above Back Scattering angle (see below)")
        ToolTip1.SetToolTip(TextBox2, "You may give full custom path here with file name" & vbCrLf & "(otherwise it will saved at default location)")
        ToolTip1.SetToolTip(Label25, "You may give full custom path here with file name" & vbCrLf & "(otherwise it will saved at default location)")
        ToolTip1.SetToolTip(Label7, "Normal Flux will be devided by this value." & vbCrLf & "Generally this is the Normal Flux of BaSO4 " & vbCrLf & "surace at i=0 and e=45 deg." & vbCrLf & "(i.e. Lambert Reflectance) ")
        'ToolTip1.SetToolTip(TextBox1, "Normal Flux will be devided by this value." & vbCrLf & "Generally this is the Normal Flux of BaSO4 " & vbCrLf & "surace at i=0 and e=45 deg." & vbCrLf & "(i.e. Lambert Reflectance) ")
        ToolTip1.SetToolTip(Label32, "Takes multiple captures at a single position")
        GroupBox10.ForeColor = Color.SaddleBrown
        incidenceAngle.Value = My.Settings.Angles(0)
        NumericUpDown1.Value = My.Settings.Angles(1)
        NumericUpDown4.Value = My.Settings.Angles(2)
        NumericUpDown7.Value = My.Settings.Angles(3)
        NumericUpDown2.Value = My.Settings.Angles(4)
        NumericUpDown3.Value = My.Settings.Angles(5)
        NumericUpDown5.Value = My.Settings.Angles(6)
        NumericUpDown6.Value = My.Settings.Angles(7)
        NumericUpDown8.Value = My.Settings.SampleSize
        NumericUpDown9.Value = My.Settings.ManStep
        NumericUpDown10.Value = My.Settings.Angles(8)
        NumericUpDown11.Value = My.Settings.OffsetAnglei
        NumericUpDown12.Value = My.Settings.OffsetAnglee
        NumericUpDown13.Value = My.Settings.CaptureNo
        RadioButton1.Checked = My.Settings.FixedButton1
        RadioButton2.Checked = My.Settings.FixedButton2
        RadioButton3.Checked = My.Settings.FixedButton3
        RichTextBox1.Text = My.Settings.SampleDetails
        TextBox2.Text = My.Settings.FilePath
        TextBox1.Text = My.Settings.RelFlux
        If Not System.IO.Directory.Exists(serialdatapath) Then System.IO.Directory.CreateDirectory(serialdatapath)
        'If Not System.IO.File.Exists(serialdatapath & "log.txt") Then System.IO.File.Create(serialdatapath & "log.txt").Close()
        'Dim thread1 As New Thread(AddressOf)
        'thread1.Start()

        Dim comPort() As String = SerialPort.GetPortNames
        For Each item In comPort
            ComboBox1.Items.Add(item)
        Next
        Try
            ComboBox1.SelectedIndex = My.Settings.PortIndex
        Catch
            ComboBox1.SelectedIndex = 0
        End Try

        Dim ToolTip As New ToolTip
        With ToolTip
            .UseAnimation = True
            .IsBalloon = True
            .ShowAlways = True
            .AutoPopDelay = 5000
            .InitialDelay = 300
            .ReshowDelay = 500
            .SetToolTip(TextBox1, "This is the value of Normalized Flux of a Lamert Surface(Spectralon or BaSO4) at i=0 and e=45 deg.")
        End With

        Communcation("Stop")
    End Sub


    Private Sub Timer1_Tick(sender As System.Object, e As System.EventArgs) Handles Timer1.Tick
        'Timer1.Stop()
        If i = 0 Then
            i = 1
            OvalShape1.BackColor = Color.LightBlue
        ElseIf i = 1 Then
            i = 0
            OvalShape1.BackColor = Color.Navy
        End If

    End Sub

    Private Sub Timer2_Tick(sender As System.Object, e As System.EventArgs) Handles Timer2.Tick
        If j = 0 Then
            j = 1
            OvalShape2.BackColor = Color.LawnGreen
        ElseIf j = 1 Then
            j = 0
            OvalShape2.BackColor = Color.DarkGreen
        End If
    End Sub

    Private Sub Timer3_Tick(sender As System.Object, e As System.EventArgs) Handles Timer3.Tick
        If k = 0 Then
            k = 1
            'OvalShape3.BackColor = Color.OrangeRed
        ElseIf k = 1 Then
            k = 0
            'OvalShape3.BackColor = Color.Maroon
        End If
    End Sub

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click

        If ArduinoPort.IsOpen = False Then
            MsgBox("Please connect the Controller first.")
            Exit Sub
        End If
        If TextBox1.Text = "" Or TextBox2.Text = "" Or RichTextBox1.Text = "" Then
            MsgBox("Some field(s) is/are empty!")
            Exit Sub
        End If
        If FileCheckStatus = False Then
            FileChecker()
            If FileCheckStatus = False Then
                Button4.Text = "Capture"
                Button4.ForeColor = Color.DarkGreen
                DataCapturing = "OFF"
                Exit Sub
            End If
        End If
        AngleFixed()
        If startangle = stopangle Then
            MsgBox(startangle & "Start angle and Stop angle OR i and e can not be same!")
            Exit Sub
        End If

        If Button1.Text = "Start" Then

            Timer1.Start()
            Timer2.Start()
            Button1.Text = "Stop"
            Button1.ForeColor = Color.Red
            Autoguide("Start")
            GroupBox3.Enabled = False
            GroupBox6.Enabled = False
            GroupBox7.Enabled = False
            NumericUpDown10.Enabled = False
        ElseIf Button1.Text = "Stop" Then

            Button1.Text = "Start"
            fixing = "NOTDONE"
            Laser = LaserFxd
            Button1.ForeColor = Color.DarkGreen
            Timer1.Stop()
            Timer2.Stop()
            OvalShape1.BackColor = Color.Navy
            OvalShape2.BackColor = Color.DarkGreen
            Autoguide("Stop")
            GroupBox3.Enabled = True
            GroupBox6.Enabled = True
            GroupBox7.Enabled = True
            NumericUpDown10.Enabled = True
            AngleFixed()
            ' If CheckBox3.Checked = True Then Me.Close()
            If TaskComplete = True Then
                'If ArduinoPort.IsOpen Then ArduinoPort.Close()
                FileWriter(filepath, "Auto Capture Compelete.", True)
                ' MsgBox("form closing")
                If CheckBox3.Checked = True Then Me.Close()
            End If
            TaskComplete = False
        End If
        'Me.Invoke(Sub() Button4.PerformClick())
    End Sub
    Private Sub TextBox1_TextChanged(sender As System.Object, e As System.EventArgs) Handles TextBox1.TextChanged
        Try
            Dim textbox1val As Single = CType(TextBox1.Text, Single)
            RelFluxDens = textbox1val
        Catch ex As Exception
            If Not TextBox1.Text.Length = 0 Then
                TextBox1.Text = TextBox1.Text.Substring(0, TextBox1.Text.Length - 1)
                TextBox1.Select(0, TextBox1.Text.Length)
            End If

        End Try

    End Sub
    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click
        Communcation("Start")

    End Sub
    Private Sub Button3_Click(sender As System.Object, e As System.EventArgs) Handles Button3.Click
        DataCapturing = "OFF"
        ArduinoPort.DtrEnable = True
        Thread.Sleep(500)
        ArduinoPort.DtrEnable = False
        Communcation("Stop")
        Label1.Text = "00.0"
        Label18.Text = "00.0"
        If Button4.Text = "Stop" Then
            Button4.Text = "Capture"
            Timer2.Stop()
            OvalShape2.BackColor = Color.DarkGreen
            Button4.ForeColor = Color.DarkGreen
            FileWriter(filepath, "User cancelled capture", True)
            LogDataWriter(Now & " User cancelled capture")
        End If
        If Button10.Text = "STOP LASER" Then
            Laser = "L0"
            LaserFxd = Laser
            Timer3.Stop()
            OvalShape3.BackColor = Color.Maroon
            Button10.Text = "START LASER"
            Button10.ForeColor = Color.DarkGreen
        End If
        If Button1.Text = "Stop" Then
            Button1.Text = "Start"
            fixing = "NOTDONE"
            Laser = LaserFxd
            Button1.ForeColor = Color.DarkGreen
            Timer1.Stop()
            Timer2.Stop()
            OvalShape1.BackColor = Color.Navy
            OvalShape2.BackColor = Color.DarkGreen
            Autoguide("Stop")
            GroupBox3.Enabled = True
            GroupBox6.Enabled = True
            GroupBox7.Enabled = True
            NumericUpDown10.Enabled = True
            AngleFixed()
            FileWriter(filepath, "Port Disconnected...Autoguide Incompelete!", True)
            TaskComplete = False
        End If


    End Sub
    Private Sub Button4_Click(sender As System.Object, e As System.EventArgs) Handles Button4.Click
        If ArduinoPort.IsOpen = False Then
            MsgBox("Please connect the Controller first.")
            Exit Sub
        End If
        If TextBox1.Text = "" Or TextBox2.Text = "" Or RichTextBox1.Text = "" Then
            MsgBox("Some field(s) is/are empty!")
            Exit Sub
        End If
        If Button4.Text = "Capture" Then

            Button4.Text = "Stop"
            Button4.ForeColor = Color.Red
            Timer2.Start()
            If FileCheckStatus = False Then
                FileChecker()
                If FileCheckStatus = False Then
                    Button4.Text = "Capture"
                    Timer2.Stop()
                    Button4.ForeColor = Color.DarkGreen
                    DataCapturing = "OFF"
                    Exit Sub
                End If
            End If
            iAngle.Clear()
            eAngle.Clear()
            DetectorValue.Clear()
            ComparatorValue.Clear()
            BDR.Clear()
            DataCapturing = "ON"
            'MsgBox("captured")
        ElseIf Button4.Text = "Stop" Then
            Button4.Text = "Capture"
            Timer2.Stop()
            OvalShape2.BackColor = Color.DarkGreen
            Button4.ForeColor = Color.DarkGreen
            DataCapturing = "OFF"
            FileWriter(filepath, "User cancelled capture", True)
            LogDataWriter(Now & " User cancelled capture")
        End If
        'MsgBox("Task Completed")

    End Sub

    Private Sub Button9_Click(sender As System.Object, e As System.EventArgs) Handles Button9.Click
        If System.IO.File.Exists(filepath) Then
            Process.Start(filepath)
        End If
    End Sub

    Private Sub Button10_Click(sender As System.Object, e As System.EventArgs) Handles Button10.Click
   
        If ArduinoPort.IsOpen = False Then
            MsgBox("Please connect the Controller first.")
            Exit Sub
        End If
  
        If Button10.Text = "START LASER" Then
            Laser = "L1"
            'Timer3.Start()
            Button10.Text = "STOP LASER"
            OvalShape3.BackColor = Color.OrangeRed
            Button10.ForeColor = Color.Red
        ElseIf Button10.Text = "STOP LASER" Then
            Laser = "L0"
            Timer3.Stop()
            OvalShape3.BackColor = Color.Maroon
            Button10.Text = "START LASER"
            Button10.ForeColor = Color.DarkGreen
        End If
        LaserFxd = Laser
 
    End Sub
    Private Sub RadioButton1_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles RadioButton1.CheckedChanged
        AngleFixed()
    End Sub

    Private Sub RadioButton3_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles RadioButton3.CheckedChanged
        AngleFixed()
    End Sub

    Private Sub RadioButton2_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles RadioButton2.CheckedChanged
        AngleFixed()
    End Sub
    Private Sub NumericUpDown1_ValueChanged(sender As System.Object, e As System.EventArgs) Handles NumericUpDown1.ValueChanged
        If NumericUpDown1.Value <= incidenceAngle.Value Then
            'MsgBox("Stop angle must be larger than Start anle")
            NumericUpDown1.Value = incidenceAngle.Value
        End If
    End Sub

    Private Sub NumericUpDown3_ValueChanged(sender As System.Object, e As System.EventArgs) Handles NumericUpDown3.ValueChanged
        If NumericUpDown3.Value <= NumericUpDown2.Value Then

            NumericUpDown3.Value = NumericUpDown2.Value
            'MsgBox("Stop angle must be larger than Start anle")
        End If
    End Sub
    Private Sub incidenceAngle_ValueChanged(sender As System.Object, e As System.EventArgs) Handles incidenceAngle.ValueChanged
        If NumericUpDown1.Value <= incidenceAngle.Value Then
            'MsgBox("Stop angle must be larger than Start anle")
            NumericUpDown1.Value = incidenceAngle.Value
        End If
    End Sub
    Private Sub NumericUpDown2_ValueChanged(sender As System.Object, e As System.EventArgs) Handles NumericUpDown2.ValueChanged


        If NumericUpDown3.Value <= NumericUpDown2.Value Then

            NumericUpDown3.Value = NumericUpDown2.Value
            'MsgBox("Stop angle must be larger than Start anle")
        End If
    End Sub
    Private Sub NumericUpDown6_ValueChanged(sender As System.Object, e As System.EventArgs) Handles NumericUpDown6.ValueChanged
        If RadioButton3.Checked = True Then
            NumericUpDown7.Value = NumericUpDown6.Value
        End If
    End Sub

    Private Sub NumericUpDown7_ValueChanged(sender As System.Object, e As System.EventArgs) Handles NumericUpDown7.ValueChanged
        If RadioButton3.Checked = True Then
            NumericUpDown6.Value = NumericUpDown7.Value
        End If
    End Sub
    Private Sub RichTextBox1_Click(sender As Object, e As System.EventArgs) Handles RichTextBox1.Click
        RichTextBox1.SelectAll()
    End Sub


    Private Sub TextBox2_Click(sender As Object, e As System.EventArgs) Handles TextBox2.Click

        TextBox2.SelectAll()
    End Sub
    Private Sub Communcation(ByVal status As String)

        If status = "Start" Then
            ArduinoPort.BaudRate = 9600
            ArduinoPort.ReadTimeout = 3000 'ms
            ArduinoPort.WriteTimeout = 3000 'ms
            ArduinoPort.PortName = ComboBox1.SelectedItem
            Dim data As String
            Try
                If Not ArduinoPort.IsOpen Then ArduinoPort.Open()
                data = ArduinoPort.ReadLine

                Label20.Text = "Connected"
                Label20.ForeColor = Color.DarkGreen
            Catch ex As Exception
                MsgBox("Error!" & vbCrLf & "You might have chosen a wrong Port or the Port is busy." & vbCrLf & "Serial Port has been closed.")
                ArduinoPort.Close()
            End Try
        ElseIf status = "Stop" Then

            Try
                If ArduinoPort.IsOpen Then ArduinoPort.Close()
                Label20.Text = "Disconnected"
                Label20.ForeColor = Color.Red
            Catch
                MsgBox("Operation failed!" & vbCrLf & "Could not disconnect port")
            End Try
        End If
    End Sub
    Delegate Sub myMethodDelegate(ByVal [text] As String)
    Dim myD1 As New myMethodDelegate(AddressOf myShowStringMethod)

    Sub myShowStringMethod(ByVal myString As String)
        Try
            Dim subs As String = myString.Substring(0, 1)
            Dim subs2 As String = myString.Substring(1, myString.Length - 2)
            If (subs = "I") Then
                Label18.Text = (CType(subs2, Single) - NumericUpDown11.Value).ToString("n1")


            End If
            If (subs = "E") Then
                Label1.Text = (CType(subs2, Single) - NumericUpDown12.Value).ToString("n1")


            End If
            If (subs = "D") Then
                D = CType(subs2, Single)


            End If
            If (subs = "C") Then
                C = CType(subs2, Single)
                Application.DoEvents()
                Try
                    If DataCapturing = "ON" Then
                        Button4.Text = "Stop"
                        Timer2.Start() 'CAUTION! THIS MAY CREATE TIMEOUT PROBLEM
                        Button4.ForeColor = Color.Red
                        iAngle.Add(CType(Label18.Text, Single))
                        eAngle.Add(CType(Label1.Text, Single))
                        DetectorValue.Add(D)
                        ComparatorValue.Add(C)
                        BDR.Add(BidirectionalReflectance(D / C, CType(Label18.Text, Single), CType(Label1.Text, Single)))
                        ListBox1.Items.Add("Capturing Data...." & iAngle.Count - 1)
                        TempDataWriter(Now & " Capturing Data...." & iAngle.Count - 1)

                        If iAngle.Count = 1 Then time1 = Now.Second
                        If iAngle.Count = 2 Then time2 = Now.Second
                        If (time2 - time1) > 2 Then
                            time1 = 0
                            time2 = 0
                            iAngle.Clear()
                            eAngle.Clear()
                            DetectorValue.Clear()
                            ComparatorValue.Clear()
                            BDR.Clear()
                            ListBox1.Items.Add("Timeout Error has occured! Retrying...")
                            TempDataWriter("Timeout Error has occured! Retrying...")
                            DataCapturing = "OFF"
                            If (Button1.Text = "Start") And (Button4.Text = "Stop") Then
                                DataCapturing = "ON"
                            End If

                            Exit Sub
                        End If

                        If ComparatorValue.Count = NumericUpDown8.Value + 1 Then
                            iAngle.RemoveAt(0)
                            eAngle.RemoveAt(0)
                            DetectorValue.RemoveAt(0)
                            ComparatorValue.RemoveAt(0)
                            Dim filetext As String = iAngle.Average & "," & eAngle.Average & "," & DetectorValue.Average & "," & ComparatorValue.Average & "," & DetectorValue.Average / ComparatorValue.Average & "," & BDR.Average & "," & 1.5 * SD(BDR) 'BidirectionalReflectance(DetectorValue.Average / ComparatorValue.Average, iAngle.Average, eAngle.Average)
                            FileWriter(filepath, filetext, True)
                            LogDataWriter(Now & " " & iAngle.Count & " " & filetext & " " & RichTextBox1.Text)
                            Button4.Text = "Capture"
                            Button4.ForeColor = Color.DarkGreen
                            Timer2.Stop()
                            OvalShape2.BackColor = Color.DarkGreen

                            dataAutoguide = True

                            DataCapturing = "OFF"


                            'Below part has been added to take multiple Capture during Autoguide. This may be completely removed without affecting main program 
                            '(((((((((**************
                            If Button1.Text = "Stop" And CaptureNumber < NumericUpDown13.Value Then
                                dataAutoguide = False
                                iAngle.Clear()
                                eAngle.Clear()
                                DetectorValue.Clear()
                                ComparatorValue.Clear()
                                BDR.Clear()
                                DataCapturing = "ON"
                                CaptureNumber += 1
                            Else
                                CaptureNumber = 1
                            End If
                            '***********))))))))

                        End If
                    End If
                    If finish = "NOTDONE" Then
                        ListBox1.Items.Add("Finshing Task... " & (50 - Abs(CType(Label1.Text, Single))) + (50 - Abs(CType(Label18.Text, Single))) & "%")
                    End If
                    ListBox1.Items.Add(Now.ToLongTimeString & " i:" & Label18.Text & " e:" & Label1.Text & " D:" & D & " C:" & C & " NormFlx:" & D / C & " BDR:" & BidirectionalReflectance(D / C, CType(Label18.Text, Single), CType(Label1.Text, Single)))
                    TempDataWriter(Now & " i:" & Label18.Text & " e:" & Label1.Text & " D:" & D & " C:" & C & " NormFlx:" & D / C & " BDR:" & BidirectionalReflectance(D / C, CType(Label18.Text, Single), CType(Label1.Text, Single)))
                    If Not D / C = 10 / 0 Then    '(Any Number)/0 is 'infinity'. So here infinity is excluded for plotting 
                        Chart1.Series(0).Points.AddXY(ListBox1.Items.Count, D / C)
                    End If
                    If CheckBox4.Checked = True Then
                        ListBox1.SelectedIndex = ListBox1.Items.Count - 1
                    End If

                Catch ex As Exception
                End Try

            End If
            'iAngle.DefaultIfEmpty()
            'Timer2.Start()
        Catch
            ListBox1.Items.Add("Serial data read Error!")
            TempDataWriter("Serial data read Error!")
        End Try

    End Sub

    Private Sub SerialPort_DataReceived(ByVal sender As Object, ByVal e As System.IO.Ports.SerialDataReceivedEventArgs) Handles ArduinoPort.DataReceived
        'MsgBox("received")
        Try
            Dim str As String = ArduinoPort.ReadLine
            Invoke(myD1, str)
            ' FileWriter(serialdatapath & "test.txt", Now.ToLongTimeString & " " & str, True)
            'MsgBox("received")
        Catch
            MsgBox("Serial read Error!")
        End Try


        If Button1.Text = "Start" Then
            If ArduinoPort.IsOpen And DataCapturing = "OFF" Then
                Dim strsend As String = finishing() 'MsgBox(Motorsend)
                ArduinoPort.Write(strsend)
                'ArduinoPort.Write(ManualSend)
                ManualSend = LaserFxd & "R0N0"
            End If
   
        Else
            If ArduinoPort.IsOpen And DataCapturing = "OFF" Then
                Dim strsend As String = Motorsend() 'MsgBox(Motorsend)
                ArduinoPort.Write(strsend)
                'FileWriter(serialdatapath & "test.txt", Now.ToLongTimeString & " " & strsend, True)
            End If
        End If

    End Sub
    Private Function Motorsend() As String
        Dim currentAngle As Single = 0
        Dim currentAngle1 As Single = 0
        Dim currentAngle2 As Single = 0
        TaskComplete = False
        If Button1.Text = "Stop" Then
            If fixing <> "DONE" Then

                If RadioButton1.Checked = True Then
                    currentAngle1 = CType(Label18.Text, Single)
                    Motorid = "M"
                    If Int(Abs(currentAngle1 - fixedangle)) > 10 Then
                        Motorstep = 10
                    ElseIf Int(Abs(currentAngle1 - fixedangle)) < 10 And Int(Abs(currentAngle1 - fixedangle)) <> 0 Then

                        Motorstep = 2
                    ElseIf Int(Abs(currentAngle1 - fixedangle)) = 0 Then
                        currentAngle2 = CType(Label1.Text, Single)
                        Motorid = "N"
                        If Int(Abs(currentAngle2 - startangle)) > 10 Then
                            Motorstep = 10
                        ElseIf Int(Abs(currentAngle2 - startangle)) < 10 And Int(Abs(currentAngle2 - startangle)) <> 0 Then
                            Motorstep = 2
                        ElseIf Int(Abs(currentAngle2 - startangle)) = 0 Then
                            fixing = "DONE"
                        End If
                        If currentAngle2 > startangle Then
                            Motordir = "R0"
                        Else
                            Motordir = "R1"
                        End If
                        Motorsend = Laser & Motordir & Motorid & Motorstep
                        Return Motorsend
                    End If
                    If currentAngle1 > fixedangle Then
                        Motordir = "R1"
                    Else
                        Motordir = "R0"
                    End If
                    Motorsend = Laser & Motordir & Motorid & Motorstep
                    Return Motorsend
                ElseIf RadioButton2.Checked = True Then
                    currentAngle1 = CType(Label1.Text, Single)
                    Motorid = "N"
                    If Int(Abs(currentAngle1 - fixedangle)) > 10 Then
                        Motorstep = 10
                    ElseIf Int(Abs(currentAngle1 - fixedangle)) < 10 And Int(Abs(currentAngle1 - fixedangle)) <> 0 Then
                        Motorstep = 2
                    ElseIf Int(Abs(currentAngle1 - fixedangle)) = 0 Then
                        currentAngle2 = CType(Label18.Text, Single)
                        Motorid = "M"
                        If Int(Abs(currentAngle2 - startangle)) > 10 Then
                            Motorstep = 10
                        ElseIf Int(Abs(currentAngle2 - startangle)) < 10 And Int(Abs(currentAngle2 - startangle)) <> 0 Then
                            Motorstep = 2
                        ElseIf Int(Abs(currentAngle2 - startangle)) = 0 Then
                            fixing = "DONE"
                        End If
                        If currentAngle2 > startangle Then
                            Motordir = "R1"
                        Else
                            Motordir = "R0"
                        End If
                        Motorsend = Laser & Motordir & Motorid & Motorstep
                        Return Motorsend

                    End If
                    If currentAngle1 > fixedangle Then
                        Motordir = "R0"
                    Else
                        Motordir = "R1"
                    End If
                    Motorsend = Laser & Motordir & Motorid & Motorstep
                    Return Motorsend
                ElseIf RadioButton3.Checked = True Then

                    currentAngle1 = CType(Label18.Text, Single)
                    Motorid = "M"
                    If Int(Abs(currentAngle1 - starti)) > 10 Then
                        Motorstep = 10
                    ElseIf Int(Abs(currentAngle1 - starti)) < 10 And Int(Abs(currentAngle1 - starti)) <> 0 Then
                        Motorstep = 2
                    ElseIf Int(Abs(currentAngle1 - starti)) = 0 Then
                        currentAngle2 = CType(Label1.Text, Single)
                        Motorid = "N"
                        If Int(Abs(currentAngle2 - starte)) > 10 Then
                            Motorstep = 10
                        ElseIf Int(Abs(currentAngle2 - starte)) < 10 And Int(Abs(currentAngle2 - starte)) <> 0 Then
                            Motorstep = 2
                        ElseIf Int(Abs(currentAngle2 - starte)) = 0 Then

                            fixing = "DONE"
                        End If
                        If currentAngle2 > starte Then
                            Motordir = "R0"
                        Else
                            Motordir = "R1"
                        End If
                        Motorsend = Laser & Motordir & Motorid & Motorstep
                        Return Motorsend
                    End If
                    If currentAngle1 > starti Then
                        Motordir = "R1"
                    Else
                        Motordir = "R0"
                    End If
                    Motorsend = Laser & Motordir & Motorid & Motorstep

                    Return Motorsend
                End If
            ElseIf fixing = "DONE" Then
                'MsgBox("fixed" & dataAutoguide & DataCapturing)
                Laser = LaserFxd
                'MsgBox("x")
                If dataAutoguide = False Then
                    'Me.Invoke(Sub() Button4.PerformClick())
                    iAngle.Clear()
                    eAngle.Clear()
                    DetectorValue.Clear()
                    ComparatorValue.Clear()
                    BDR.Clear()
                    DataCapturing = "ON"
                    Motorstep = 0
                    Motorsend = Laser & Motordir & Motorid & Motorstep
                    ' MsgBox(Motorsend)
                    Return Motorsend
                End If

                ' MsgBox("xx")


                If RadioButton3.Checked = True Then
                    

                    Motordir = "R0"
                    Motorid = "P"
                    If Abs(CType(Label18.Text, Single)) <= 70 Or Abs(CType(Label1.Text, Single)) <= 70 Then
                        Motorstep = stepie * 4.1
                        Laser = "L2"
                    Else                       
                        Laser = "L0"
                        Motorstep = 0
                        TaskComplete = True
                        'finish = "DONE"
                        fixing = "NOTDONE"
                        Button1.ForeColor = Color.DarkGreen
                        Timer1.Stop()

                        Autoguide("Stop")

                        '''''''''''''''''''''''''''''''''''''''''' This part included on 27/3/20
                        If CheckBox1.Checked = True Then
                            finish = "DONE"
                        Else
                            finish = "NOTDONE"

                        End If
                        ''''''''''''''''''''''''''''''''''''''''


                        '      finish = "NOTDONE"              'IF ABOVE PART IS DELETED THEN UNCOMMENT THIS LINE

                        'AngleFixed()
                        Me.Invoke(Sub() Button1.PerformClick())
                        'If CheckBox3.Checked = True Then Me.Close()
                    End If

                    'PhaseCheck()

                    ' Asking for serial incoming delay
                    Motorsend = Laser & Motordir & Motorid & Motorstep
                    'MsgBox(Motorsend)
                    'Motorsend = "R1N0"
                    dataAutoguide = False
                    ' MsgBox(Motorsend)
                    Return Motorsend
                Else
                    If stopangle > startangle Then
                        If RadioButton1.Checked Then
                            Motordir = "R1"
                        ElseIf RadioButton2.Checked Then
                            Motordir = "R0"
                        End If

                    ElseIf stopangle < startangle Then
                        If RadioButton1.Checked Then
                            Motordir = "R0"
                        ElseIf RadioButton2.Checked Then
                            Motordir = "R1"
                        End If
                    End If
                    If RadioButton1.Checked = True Then
                        Motorid = "N"
                        currentAngle = CType(Label1.Text, Single)
                    ElseIf RadioButton2.Checked = True Then
                        Motorid = "M"
                        currentAngle = CType(Label18.Text, Single)
                    End If
                    If Abs(CType(Label1.Text, Single) - CType(Label18.Text, Single)) < NumericUpDown10.Value Then
                        Motorstep = stepsmall * 4.1

                    ElseIf Abs(CType(Label1.Text, Single) - CType(Label18.Text, Single)) >= NumericUpDown10.Value Then
                        Motorstep = steplarge * 4.1

                    End If
                    Laser = "L2"   ' Asking for serial incoming delay
                    If currentAngle > stopangle Then
                        Laser = "L0"
                        Motorstep = 0

                        fixing = "NOTDONE"
                        Button1.ForeColor = Color.DarkGreen
                        Timer1.Stop()

                        Autoguide("Stop")

                        'AngleFixed()
                        TaskComplete = True

                        '''''''''''''''''''''''''''''''''''''''''' This part included on 27/3/20
                        If CheckBox1.Checked = True Then
                            finish = "DONE"
                        Else
                            finish = "NOTDONE"

                        End If
                        ''''''''''''''''''''''''''''''''''''''''


                        '      finish = "NOTDONE"              'IF ABOVE PART IS DELETED THEN UNCOMMENT THIS LINE

                        Me.Invoke(Sub() Button1.PerformClick())
                    End If

                    Motorsend = Laser & Motordir & Motorid & Motorstep
                    dataAutoguide = False
                    ' MsgBox(Motorsend)
                    Return Motorsend
            End If
            End If
        ElseIf Button1.Text = "Start" Then
            Motorsend = Laser & "R0N0"
            dataAutoguide = False
            Return Motorsend
        End If
    End Function
    Private Sub PhaseCheck()  'Made for precise const. phase angle check if Radiobutton3 is checked. Could not use it. Can be deleted.

        If Convert.ToInt32(CType(Label1.Text, Single) - CType(Label18.Text, Single)) > Convert.ToInt32(NumericUpDown2.Value - incidenceAngle.Value) Then
            dataAutoguide = True
            Motorid = "M"
            Motordir = "R0"
            Motorstep = 2
        ElseIf Convert.ToInt32(CType(Label1.Text, Single) - CType(Label18.Text, Single)) < Convert.ToInt32(NumericUpDown2.Value - incidenceAngle.Value) Then
            dataAutoguide = True
            Motorid = "M"
            Motordir = "R1"
            Motorstep = 2
        Else

            dataAutoguide = False

        End If

    End Sub
    Private Function finishing() As String  'Ths Function intended for aligning the arms at a finish position after completing auto-capture. COULD NOT USE IT. Can be deleted.
        'MsgBox("")

        If finish = "NOTDONE" Then
            
            Motorid = "N"
            If Int(Abs(CType(Label1.Text, Single) + 0.0)) > 10 Then
                Motorstep = 10
            ElseIf Int(Abs(CType(Label1.Text, Single) + 0.0)) < 10 And Int(Abs(CType(Label1.Text, Single) + 0.0)) <> 0 Then

                Motorstep = 2
            ElseIf Int(Abs(CType(Label1.Text, Single) + 0.0)) = 0 Then
                Motorid = "M"
                If Int(Abs(CType(Label18.Text, Single) - 0.0)) > 10 Then
                    Motorstep = 10
                ElseIf Int(Abs(CType(Label18.Text, Single) - 0.0)) < 10 And Int(Abs(CType(Label18.Text, Single) - 0.0)) <> 0 Then
                    Motorstep = 2
                ElseIf Int(Abs(CType(Label18.Text, Single) - 0.0)) = 0 Then
                    finish = "DONE"
                    'Invoke(Sub() Button3.PerformClick())

                    'Form2.ShowDialog()
                    'Communcation("Stop")
                    'MsgBox("Task Finished")
                    'ListBox1.Items.Add("Task Finished")
                End If
                If CType(Label18.Text, Single) > 0.0 Then
                    Motordir = "R1"
                Else
                    Motordir = "R0"
                End If
                finishing = Laser & Motordir & Motorid & Motorstep
                'ListBox1.Items.Add("Finalizing arm positions...")
                Return finishing
            End If
            If CType(Label1.Text, Single) > -0.0 Then
                Motordir = "R0"
            Else
                Motordir = "R1"
            End If
            finishing = Laser & Motordir & Motorid & Motorstep
            'ListBox1.Items.Add("Finalizing arm positions...")
            Return finishing
        Else
            finishing = ManualSend
        End If
        
    End Function

    Private Sub AngleFixed()
        If RadioButton1.Checked = True Then
            incidenceAngle.Enabled = True
            NumericUpDown1.Enabled = False
            NumericUpDown4.Enabled = False
            NumericUpDown7.Enabled = False
            NumericUpDown2.Enabled = True
            NumericUpDown3.Enabled = True
            NumericUpDown5.Enabled = True
            NumericUpDown6.Enabled = True
            NumericUpDown10.Enabled = True

            incidenceAngle.BackColor = System.Drawing.SystemColors.Window
            NumericUpDown1.BackColor = System.Drawing.SystemColors.ControlDarkDark
            NumericUpDown4.BackColor = System.Drawing.SystemColors.ControlDarkDark
            NumericUpDown7.BackColor = System.Drawing.SystemColors.ControlDarkDark
            NumericUpDown2.BackColor = System.Drawing.SystemColors.Window
            NumericUpDown3.BackColor = System.Drawing.SystemColors.Window
            NumericUpDown5.BackColor = System.Drawing.SystemColors.Window
            NumericUpDown6.BackColor = System.Drawing.SystemColors.Window
            NumericUpDown10.BackColor = System.Drawing.SystemColors.Window
            fixedangle = incidenceAngle.Value
            startangle = NumericUpDown2.Value
            stopangle = NumericUpDown3.Value
            stepsmall = NumericUpDown5.Value
            steplarge = NumericUpDown6.Value
        ElseIf RadioButton2.Checked = True Then
            incidenceAngle.Enabled = True
            NumericUpDown1.Enabled = True
            NumericUpDown4.Enabled = True
            NumericUpDown7.Enabled = True
            NumericUpDown2.Enabled = True
            NumericUpDown3.Enabled = False
            NumericUpDown5.Enabled = False
            NumericUpDown6.Enabled = False
            NumericUpDown10.Enabled = True

            incidenceAngle.BackColor = System.Drawing.SystemColors.Window
            NumericUpDown1.BackColor = System.Drawing.SystemColors.Window
            NumericUpDown4.BackColor = System.Drawing.SystemColors.Window
            NumericUpDown7.BackColor = System.Drawing.SystemColors.Window
            NumericUpDown2.BackColor = System.Drawing.SystemColors.Window
            NumericUpDown3.BackColor = System.Drawing.SystemColors.ControlDarkDark
            NumericUpDown5.BackColor = System.Drawing.SystemColors.ControlDarkDark
            NumericUpDown6.BackColor = System.Drawing.SystemColors.ControlDarkDark
            NumericUpDown10.BackColor = System.Drawing.SystemColors.Window
            fixedangle = NumericUpDown2.Value
            startangle = incidenceAngle.Value
            stopangle = NumericUpDown1.Value
            stepsmall = NumericUpDown4.Value
            steplarge = NumericUpDown7.Value
        ElseIf RadioButton3.Checked = True Then
            incidenceAngle.Enabled = True
            NumericUpDown1.Enabled = False
            NumericUpDown4.Enabled = False
            NumericUpDown7.Enabled = True
            NumericUpDown2.Enabled = True
            NumericUpDown3.Enabled = False
            NumericUpDown5.Enabled = False
            NumericUpDown6.Enabled = True
            NumericUpDown6.Value = NumericUpDown7.Value
            NumericUpDown10.Enabled = False

            incidenceAngle.BackColor = System.Drawing.SystemColors.Window
            NumericUpDown1.BackColor = System.Drawing.SystemColors.ControlDarkDark
            NumericUpDown4.BackColor = System.Drawing.SystemColors.ControlDarkDark
            NumericUpDown7.BackColor = System.Drawing.SystemColors.Window
            NumericUpDown2.BackColor = System.Drawing.SystemColors.Window
            NumericUpDown3.BackColor = System.Drawing.SystemColors.ControlDarkDark
            NumericUpDown5.BackColor = System.Drawing.SystemColors.ControlDarkDark
            NumericUpDown6.BackColor = System.Drawing.SystemColors.Window
            NumericUpDown10.BackColor = System.Drawing.SystemColors.ControlDarkDark

            starti = incidenceAngle.Value
            starte = NumericUpDown2.Value
            stepie = NumericUpDown7.Value

            startangle = starti  'These are irrelevant here but are included to only correctly run first MsgBox in Button1
            stopangle = starte   '   "

        End If

    End Sub

    Private Sub Autoguide(ByVal status As String)
        Dim coarse As Integer = 400
        Dim fine As Integer = 20


        If status = "Start" Then
            If RadioButton1.Checked = True Then

                StepperDriver1("M")
            ElseIf RadioButton2.Checked = True Then

                StepperDriver1("N")
            ElseIf RadioButton3.Checked = True Then

                StepperDriver1("MN")
            End If

        ElseIf status = "Stop" Then
            Motorstep = 0
        End If

    End Sub
    Private Sub StepperDriver1(ByVal FixedStepper As String)
        Dim currentAngle As Single = 0
        If FixedStepper = "M" Then
            currentAngle = CType(Label18.Text, Single)
        ElseIf FixedStepper = "N" Then
            currentAngle = CType(Label1.Text, Single)
        ElseIf FixedStepper = "MN" Then


        End If
        If currentAngle > fixedangle Then
            Motordir = "R1"
        Else
            Motordir = "R0"
        End If
        If Abs(currentAngle - fixedangle) > 10 Then

        End If
    End Sub


    Private Sub Timer4_Tick(sender As System.Object, e As System.EventArgs)

    End Sub



    Private Sub FileChecker()
        If TextBox2.Text.Count = 0 Then
            MsgBox("Please enter a file name")
            Exit Sub
        End If
        filepath = TextBox2.Text
        If TextBox2.Text.IndexOf("\") = -1 Then
            filepath = serialdatapath & "\" & TextBox2.Text
        End If
        If System.IO.File.Exists(filepath) Then
            Dim yesnoresult As Integer = MessageBox.Show("A file with this name already exist in this path. Would you like to overwrite it?", "Goniometer Controller", MessageBoxButtons.YesNoCancel)
            If yesnoresult = DialogResult.Yes Then
                FileWriter(filepath, "Sample Details: " & RichTextBox1.Text & vbCrLf & "Relative Flux: " & TextBox1.Text & vbCrLf & "Sampling Size: " & NumericUpDown8.Value & vbCrLf & "Date & Time: " & Now.ToLongDateString & " " & Now.ToShortTimeString, False)
                FileWriter(filepath, "i(deg),e(deg),Detector Count,Comparator Count,Av. Flux,BDR,(+-)error", True)
            ElseIf yesnoresult = DialogResult.No Then
                MsgBox("No changes on existing heading will be done")
            ElseIf yesnoresult = DialogResult.Cancel Then
                OvalShape2.BackColor = Color.DarkGreen
                Exit Sub
            End If
        Else
            FileWriter(filepath, "Sample Details: " & RichTextBox1.Text & vbCrLf & "Relative Flux: " & TextBox1.Text & vbCrLf & "Sampling Size: " & NumericUpDown8.Value & vbCrLf & "Date & Time: " & Now.ToLongDateString & " " & Now.ToShortTimeString, False)
            FileWriter(filepath, "i(deg),e(deg),Detector Count,Comparator Count,Av. Flux,BDR,(+-)error", True)
        End If

        FileCheckStatus = True
    End Sub

    Private Function FileWriter(ByVal path As String, ByVal myText As String, ByVal TrueFalse As Boolean)
        Try
            Dim objwriter As New System.IO.StreamWriter(path, TrueFalse)  'True to append and False to overwrite
            objwriter.WriteLine(myText)
            objwriter.Close()
        Catch ex As Exception
            MsgBox("The file is not accessable." & vbCrLf & "It might be opened by another program.")
        End Try
    End Function
    Private Function LogDataWriter(ByVal myText As String)
        Dim objwriter As New System.IO.StreamWriter(serialdatapath & "LoggedData.txt", True)
        objwriter.WriteLine(myText)
        objwriter.Close()
    End Function
    Private Function TempDataWriter(ByVal myText As String)
        Dim objwriter As New System.IO.StreamWriter(serialdatapath & "temp.txt", True)
        objwriter.WriteLine(myText)
        objwriter.Close()
    End Function

    Private Function BidirectionalReflectance(ByVal FluxDens As Single, ByVal iDeg As Single, ByVal eDeg As Single) As Single
        Dim iRadAngle As Single = iDeg * Math.PI / 180
        Dim eRadAngle As Single = eDeg * Math.PI / 180
        Dim reflectance As Single = ((1 / Math.PI) * (FluxDens / RelFluxDens) * (Math.Cos(iRadAngle) / Math.Cos(eRadAngle)) * Math.Cos((Math.PI / 180) * 45))
        Return reflectance
    End Function
    Private Function SD(ByVal Array As List(Of Single))  'Standard Deviation
        Dim Av As Single = Array.Average
        Dim N As Single = Array.Count - 1
        Dim SSum As Single = 0
        For ii = 0 To N
            SSum = SSum + (Array(ii) - Av) ^ 2
        Next
        Dim StDev As Single = Math.Sqrt(SSum / N)
        Array.Clear()
        Return StDev
    End Function



    Private Sub TextBox2_TextChanged(sender As System.Object, e As System.EventArgs) Handles TextBox2.TextChanged
        FileCheckStatus = False
    End Sub

    Private Sub ComboBox1_Click(sender As Object, e As System.EventArgs) Handles ComboBox1.Click
        ComboBox1.Items.Clear()
        Dim comPort() As String = SerialPort.GetPortNames
        For Each item In comPort
            ComboBox1.Items.Add(item)
        Next
    End Sub

    Private Sub btn1text()
        Button1.Text = "Start"
    End Sub
    Private Sub TimeoutErrorCheck()

    End Sub
    Private Sub Button5_Click(sender As System.Object, e As System.EventArgs) Handles Button5.Click
        Chart1.Series(0).Points.Clear()
    End Sub

    Private Sub Button11_Click(sender As System.Object, e As System.EventArgs) Handles Button11.Click
        'Dim zsd As Single = -2.6
        'MsgBox(Abs(zsd))
        If System.IO.File.Exists(serialdatapath & "\LoggedData.txt") Then
            Process.Start(serialdatapath & "\LoggedData.txt")
        End If
    End Sub

    Private Sub CheckBox3_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles CheckBox3.CheckedChanged
        If CheckBox3.Checked = True Then
            CheckBox3.ForeColor = Color.Red
        Else
            CheckBox3.ForeColor = Color.Navy
        End If
    End Sub


    Private Sub Button6_Click(sender As System.Object, e As System.EventArgs) Handles Button6.Click
        If ArduinoPort.IsOpen = False Then
            MsgBox("Please connect the Controller first.")
            Exit Sub
        End If
        If Button1.Text = "Stop" Then
            Exit Sub
        End If

        Dim manualdir As String
        Dim manuallaser As String = LaserFxd
        Dim manualmotor As String
        Dim manualstep As Integer = CType(NumericUpDown9.Value, Single) * 4.1 ' / 0.1428

        If RadioButton6.Checked Then
            manualmotor = "M"
            If RadioButton4.Checked Then
                manualdir = "R0"
            ElseIf RadioButton5.Checked Then
                manualdir = "R1"
            End If
        ElseIf RadioButton7.Checked Then
            manualmotor = "N"
            If RadioButton4.Checked Then
                manualdir = "R1"
            ElseIf RadioButton5.Checked Then
                manualdir = "R0"
            End If
        End If
        ManualSend = manuallaser & manualdir & manualmotor & manualstep

    End Sub

    Private Sub Label16_Click(sender As System.Object, e As System.EventArgs) Handles Label16.Click

    End Sub

    Private Sub Label6_Click(sender As System.Object, e As System.EventArgs) Handles Label6.Click

    End Sub



End Class
